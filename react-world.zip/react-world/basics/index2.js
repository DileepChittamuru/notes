var infractions = [
    {
        "plate": "ABCD 123",
        "date": "2014-12-24",
        "type": "speeding"
    },
    {
        "plate": "ABCD I23",
        "date": "2015-02-15",
        "type": "failure.to.stop.at.stop.sign"
    },
    {
        "plate": "ABCD 123",
        "date": "2016-04-14",
        "type": "operating.mobile.device"
    }
];

function getMostRecentInfractionForVehicle(plate) {
    return infractions
    .filter(item => item.plate === plate)
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .shift();
}

var result = getMostRecentInfractionForVehicle('ABCD 123');
console.log(result);