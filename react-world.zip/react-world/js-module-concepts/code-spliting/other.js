
export const OtherComponent = () => {
    return (<div>
        <h2>other OtherComponent loading</h2>
    </div>)
};

