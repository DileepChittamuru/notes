export function sayHi() {
    return 'Hai';
}